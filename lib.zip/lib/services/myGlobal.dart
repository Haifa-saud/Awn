library globals;

String bDay = "";
String userType = "";
String User_name = "";
