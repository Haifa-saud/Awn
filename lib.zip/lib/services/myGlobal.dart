library globals;

String bDay = "";
String userType = "";
